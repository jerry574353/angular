export class User {
    id!: number;
    firstName!: string;
    lastName!: string;
    pen!: string;
}       